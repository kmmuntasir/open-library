<?php
	header("Location: ../index.php/admin");
?>