<div class="row">
	<div class="col-xs-12 sync_page">
		<i class="fa fa-refresh fa-spin sync_page_icon"></i>
	    <h4 class="sync_heading">Last Sync</h4>
	    <span class="text-muted sync_time">8:55 pm, June 9, 2016</span>
	    <div class="row">
	    <div class="col-xs-5"></div>
	    <button class="btn btn-primary col-xs-2"><i class="fa fa-refresh"></i></button>
	    <div class="col-xs-5"></div>
	    </div>
	</div>
</div>