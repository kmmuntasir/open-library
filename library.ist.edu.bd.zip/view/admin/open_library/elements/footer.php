<nav class="navbar navbar-inverse navbar-fixed-bottom">
    Hello World
</nav>