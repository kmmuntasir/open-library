# open_library_manager
This is an open source library management system for any educational institute.
This is a test.
